-------------------------
-- DB PROJECT STRUCTURE--
-- schema version 1.02 --
-------------------------

CREATE TABLE IF NOT EXISTS ProjectStructureContent (
    content_id INTEGER PRIMARY KEY,
    content BLOB
);

INSERT INTO ProjectStructureContent (content_id, content) SELECT id, content FROM ProjectStructure;

DROP TRIGGER IF EXISTS before_update_ProjectStructure;
UPDATE ProjectStructure SET content = NULL;
--restore trigger
CREATE TRIGGER IF NOT EXISTS before_update_ProjectStructure BEFORE UPDATE ON ProjectStructure
BEGIN
 SELECT CASE
    WHEN ( EXISTS (SELECT * from ProjectStructure WHERE parentId = new.parentId AND name = new.name AND (extension = new.extension OR (extension IS NULL AND new.extension IS NULL)) AND id != new.id AND deleted IS NULL) )
    THEN RAISE (FAIL, 'Item is not unique')
 END;
END;

ALTER TABLE ProjectStructure RENAME COLUMN content TO icon;

DROP TRIGGER IF EXISTS before_delete_ProjectStructure;
CREATE TRIGGER IF NOT EXISTS before_delete_ProjectStructure BEFORE DELETE ON ProjectStructure
BEGIN
 DELETE FROM CloudStructure WHERE projectId = old.id;
 DELETE FROM ProjectQuickAccess WHERE projectId = old.id OR projectAccessId = old.id;
 DELETE FROM ProjectStructureContent WHERE content_Id = old.id;
END;

UPDATE ProjectConfiguration SET
    schemaVersion = 1.02
WHERE schemaVersion < 1.02; -- upgrade to new schema 1.02 if necessary

