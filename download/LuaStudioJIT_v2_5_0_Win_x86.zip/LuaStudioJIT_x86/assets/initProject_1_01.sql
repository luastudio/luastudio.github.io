-------------------------
-- DB PROJECT STRUCTURE--
-- schema version 1.01 --
-------------------------

--DROP TABLE IF EXISTS ProjectQuickAccess;
CREATE TABLE IF NOT EXISTS ProjectQuickAccess (
    projectId INTEGER NOT NULL, --from ProjectStructure
    projectAccessId INTEGER NOT NULL, --from ProjectStructure
    UNIQUE(projectId, projectAccessId)
);

CREATE TRIGGER IF NOT EXISTS before_delete_ProjectStructure BEFORE DELETE ON ProjectStructure
BEGIN
 DELETE FROM CloudStructure WHERE projectId = old.id;
 DELETE FROM ProjectQuickAccess WHERE projectId = old.id OR projectAccessId = old.id;
END;

CREATE INDEX IF NOT EXISTS ProjectQuickAccess_projectId_INDEX ON ProjectQuickAccess (projectId);

INSERT INTO SupportedCloudSystem (id, name)
SELECT 2, 'OneDrive'
WHERE NOT EXISTS (SELECT * FROM SupportedCloudSystem WHERE id = 2 LIMIT 1);

INSERT INTO SupportedCloudSystem (id, name)
SELECT 3, 'Dropbox'
WHERE NOT EXISTS (SELECT * FROM SupportedCloudSystem WHERE id = 3 LIMIT 1);

UPDATE ProjectConfiguration SET
    schemaVersion = 1.01
WHERE schemaVersion < 1.01; -- upgrade to new schema 1.01 if necessary
