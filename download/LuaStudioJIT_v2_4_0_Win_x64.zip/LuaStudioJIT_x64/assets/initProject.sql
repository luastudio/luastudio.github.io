-------------------------
-- DB PROJECT STRUCTURE--
-- schema version 1.00 --
-------------------------

CREATE TABLE IF NOT EXISTS ProjectConfiguration (
    name TEXT DEFAULT 'New Project' NOT NULL,
    version REAL DEFAULT 0.0 NOT NULL,
    schemaVersion REAL DEFAULT 1.0 NOT NULL,
    startId INTEGER DEFAULT 1 NOT NULL, -- project start script id
    defaultCloudSystemId INTEGER
);

INSERT INTO ProjectConfiguration (name, version, startId, defaultCloudSystemId)
SELECT 'New Project', 0.0, 1, 1
WHERE NOT EXISTS (SELECT * FROM ProjectConfiguration LIMIT 1);

CREATE TABLE IF NOT EXISTS SupportedCloudSystem (
	id INTEGER NOT NULL PRIMARY KEY,
	name TEXT NOT NULL UNIQUE
);

INSERT INTO SupportedCloudSystem (id, name)
SELECT 1, 'Google Drive'
WHERE NOT EXISTS (SELECT * FROM SupportedCloudSystem WHERE id = 1 LIMIT 1);

CREATE TABLE IF NOT EXISTS CloudStructure (
    cloudId INTEGER NOT NULL,--from SupportedCloudSystem
    projectId INTEGER NOT NULL, --from ProjectStructure
    cloudKey TEXT NOT NULL,
    cloudSize INTEGER NOT NULL DEFAULT 0,
    cloudMofidied TEXT,
    cloudDownloadProgress INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ProjectStructure (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parentId INTEGER NOT NULL, -- -1 - root
    type INTEGER, -- 0 - folder, 1 - file
    name TEXT NOT NULL,
    extension TEXT,
    markers TEXT, --comma separated integers
    flag INTEGER NOT NULL DEFAULT 0, -- executable, debuggable, ...
    locked INTEGER NOT NULL DEFAULT 0, --1 - locked, 0 - not
    --time
    created DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, --GMT
    modified DATETIME, --GMT
    deleted DATETIME, --GMT
    created_localtime DATETIME DEFAULT (datetime('now','localtime')) NOT NULL, --localtime
    modified_localtime DATETIME, --localtime
    deleted_localtime DATETIME, --localtime
    --content
    content_type TEXT,
    content BLOB
);

INSERT INTO ProjectStructure (parentId, type, name, extension, flag, content_type, content)
SELECT -1, 1, 'Main', 'lua', 1, 'text/plain', 'print("Hello World!")'--||CHAR(10)||'Test'
WHERE NOT EXISTS (SELECT * FROM ProjectStructure LIMIT 1);

CREATE TRIGGER IF NOT EXISTS before_insert_ProjectStructure BEFORE INSERT ON ProjectStructure
BEGIN
 SELECT CASE
    WHEN ( EXISTS (SELECT * from ProjectStructure WHERE parentId = new.parentId AND name = new.name AND (extension = new.extension OR (extension IS NULL AND new.extension IS NULL)) AND deleted IS NULL) )
    THEN RAISE (FAIL, 'Item is not unique')
 END;
END;

CREATE TRIGGER IF NOT EXISTS before_update_ProjectStructure BEFORE UPDATE ON ProjectStructure
BEGIN
 SELECT CASE
    WHEN ( EXISTS (SELECT * from ProjectStructure WHERE parentId = new.parentId AND name = new.name AND (extension = new.extension OR (extension IS NULL AND new.extension IS NULL)) AND id != new.id AND deleted IS NULL) )
    THEN RAISE (FAIL, 'Item is not unique')
 END;
END;

CREATE INDEX IF NOT EXISTS ProjectStructure_parentId_INDEX ON ProjectStructure (parentId);
CREATE INDEX IF NOT EXISTS CloudStructure_projectId_INDEX ON CloudStructure (projectId);